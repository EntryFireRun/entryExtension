function mess(a) {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.engine.raiseMessage(a);
}

function getm() {
  console.log("[신호 리스트 출력 결과]");
  console.log(
    window.document.getElementsByTagName("iframe")[0].contentWindow.Entry
      .variableContainer.messages_
  );
  console.log(`\n`);
}

function objm(a, b) {
  b *= 20;
  let count = 0;
  let leftTime = b / 200;
  let stopmove = 0;
  alertPopup = document.createElement("h1");
  alertPopup.style.position = "fixed";
  alertPopup.style.padding = "10px";
  alertPopup.style.right = "10px";
  alertPopup.style.borderRadius = "10px";
  alertPopup.style.border = "3px solid #33bb77";
  alertPopup.style.bottom = "10px";
  alertPopup.style.backgroundColor = "#22aa66";
  alertPopup.style.color = "#fff";
  document.body.append(alertPopup);
  window.addEventListener(
    "keydown",
    (e) => {
      e.key == "\\" ? (stopmove = 1) : null;
    },
    { once: true }
  );
  loop = setInterval(() => {
    document
      .getElementsByTagName("iframe")[0]
      .contentWindow.Entry.container.objects_[a].entity.setX(
        parseInt(
          document.getElementsByTagName("iframe")[0].contentWindow.Entry.stage
            .mouseCoordinate.x
        )
      );
    document
      .getElementsByTagName("iframe")[0]
      .contentWindow.Entry.container.objects_[a].entity.setY(
        parseInt(
          document.getElementsByTagName("iframe")[0].contentWindow.Entry.stage
            .mouseCoordinate.y
        )
      );
    count++;
    leftTime = leftTime - 0.005;
    alertPopup.innerText = `${leftTime.toFixed(
      1
    )}초 남음\n작품 화면 바깥에서 \\를 누르면 작동이 중지됩니다\n시간은 실제보다 속도가 약간 빠릅니다`;
    if (count >= b || stopmove == 1) {
      clearInterval(loop);
      alertPopup.remove();
    }
  });
}

function gifi(a, b) {
  console.log(a);
  c = fetch(`https://playentry.org/rest/picture/project/thumbnail/${b}`, {
    headers: {
      "content-type": "application/json",
      "csrf-token": `${
        JSON.parse(document.getElementById("__NEXT_DATA__").innerText).props
          .initialProps.csrfToken
      }`,
      "x-client-type": "Client",
      "x-token": `${
        JSON.parse(document.getElementById("__NEXT_DATA__").innerText).props
          .initialState.common.user.xToken
      }`,
    },
    referrerPolicy: "unsafe-url",
    body: `{"thumbnail":"${a}"}`,
    method: "POST",
    mode: "cors",
    credentials: "include",
  });
  console.log(c);
}

function nick(a) {
  window.document.getElementsByTagName(
    "iframe"
  )[0].contentWindow.user.nickname = a;
}

function user(a) {
  window.document.getElementsByTagName(
    "iframe"
  )[0].contentWindow.user.username = a;
}

function objl() {
  console.log("[오브젝트 리스트 출력 결과]");
  console.log(
    window.document.getElementsByTagName("iframe")[0].contentWindow.Entry
      .container.objects_
  );
  console.log(`\n`);
}

function objx(a, b) {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.container.objects_[parseInt(a)].entity.setX(
      parseInt(b)
    );
}

function objy(a, b) {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.container.objects_[parseInt(a)].entity.setY(
      parseInt(b)
    );
}

function senc() {
  Entry.scene.updateView = function (Ỿ, ꝍ) {
    this.prevButton_.removeClass`entryRemove`;
    this.nextButton_.removeClass`entryRemove`;
    this.nextAddButton_.removeClass`entryRemove`;
    this.updateSceneView();
    this.resize();
  };
  Entry.scene.updateView();
}

function list(a, b, c) {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.variableContainer.getListByName(a)
    .insertValue(parseInt(b), c);
}

function fltm(a, b, c) {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.variableContainer.getListByName(a)
    .replaceValue(parseInt(b), c);
}

function varq(a, b) {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.variableContainer.getVariableByName(a)
    .setValue(b);
}

function loop() {
  Entry.isTurbo = true;
}

function qksq() {
  window.document.getElementsByTagName(
    "iframe"
  )[0].contentWindow.Entry.isTurbo = true;
}

function wprj(a, b) {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.variableContainer.getListByName(a)
    .deleteValue(b);
}

function boos() {
  if (
    window.document.getElementsByTagName("iframe")[0].contentWindow.Entry
      .options.useWebGL == false
  ) {
    window.document.getElementsByTagName(
      "iframe"
    )[0].contentWindow.Entry.options.useWebGL = true;
  } else {
    window.document.getElementsByTagName(
      "iframe"
    )[0].contentWindow.Entry.options.useWebGL = false;
  }
}

function time() {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.engine.resetTimer();
}

function sele(a) {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.scene.selectScene(
      window.document
        .getElementsByTagName("iframe")[0]
        .contentWindow.Entry.scene.getScenes()[a]
    );
}

function gets() {
  console.log("[장면 리스트 출력 결과]");
  console.log(
    window.document
      .getElementsByTagName("iframe")[0]
      .contentWindow.Entry.scene.getScenes()
  );
  console.log(`\n`);
}

function when() {
  window.document
    .getElementsByTagName("iframe")[0]
    .contentWindow.Entry.engine.fireEvent("when_scene_start");
}

function clon() {
  window.document.getElementsByTagName(
    "iframe"
  )[0].contentWindow.Entry.maxCloneLimit = NaN;
}

function fpsu() {
  const EhdlqfurgkwlaktpdyWW = 1;
  if (typeof EhdlqfurgkwlaktpdyWW == "number") {
    let wasans = 1;
    if (Entry.FPS == 300) {
      wasans = 0;
    }
    Entry.engine.speeds[5] = 300; // undefind나 null등으로 적은 경우, 작품 상세 페이지에서 64fps로 동작하기 때문에 300으로 변경 (테스트 결과 250 이상은 '그 방법' 없이는 못 넘는 듯)
    document.getElementsByClassName("entrySpeedButtonWorkspace")[0].click();
    document
      .getElementsByClassName("entrySpeedButtonWorkspace")[0]
      .addEventListener("click", () => {
        if (
          document
            .getElementsByClassName("entrySpeedButtonWorkspace")[0]
            .classList.contains("on")
        ) {
          document.getElementById("progressCell5").style.backgroundColor =
            "blue";
          document
            .getElementById("progressCell5")
            .addEventListener("click", () => {
              document.getElementById("progressCell4").classList.remove("on");
              document.getElementById("progressCell3").classList.remove("on");
              document.getElementById("progressCell2").classList.remove("on");
              document.getElementById("progressCell1").classList.remove("on");
              document.getElementById("progressCell5").classList.add("on");
              wasans = 0;
            });
          document
            .getElementById("progressCell4")
            .addEventListener("click", () => {
              wasans = 1;
            });
          document
            .getElementById("progressCell3")
            .addEventListener("click", () => {
              wasans = 1;
            });
          document
            .getElementById("progressCell2")
            .addEventListener("click", () => {
              wasans = 1;
            });
          document
            .getElementById("progressCell1")
            .addEventListener("click", () => {
              wasans = 1;
            });
          if (wasans == 0) {
            document.getElementById("progressCell5").click();
          }
        }
      });
    document.getElementsByClassName("entrySpeedButtonWorkspace")[0].click();
  }
  // 코드 야매로 구현함ㅋ
}

////////////////////////////////////////////////////////
////////////////////////////////////////////////////////

function nickname() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: nick,
      args: [document.getElementById("nick1").value],
      world: "MAIN",
    });
  });
  document.getElementById("nick").style.display = "block";
  document.getElementById("nickname").style.display = "none";
  setTimeout(function () {
    document.getElementById("nick").style.display = "none";
    document.getElementById("nickname").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function username() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: user,
      args: [document.getElementById("user1").value],
      world: "MAIN",
    });
  });
  document.getElementById("user").style.display = "block";
  document.getElementById("username").style.display = "none";
  setTimeout(function () {
    document.getElementById("user").style.display = "none";
    document.getElementById("username").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function korean() {
  document.getElementById("kore1").value = document
    .getElementById("kore1")
    .value.normalize("NFD");
  document.getElementById("kore").style.display = "block";
  document.getElementById("korean").style.display = "none";
  document.getElementById("kore1").style.color = "lime";
  setTimeout(function () {
    document.getElementById("kore").style.display = "none";
    document.getElementById("korean").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function objlist() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: objl,
      world: "MAIN",
    });
  });
  document.getElementById("objl").style.display = "block";
  document.getElementById("objlist").style.display = "none";
  setTimeout(function () {
    document.getElementById("objl").style.display = "none";
    document.getElementById("objlist").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function objxpos() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: objx,
      args: [
        document.getElementById("objx1").value,
        document.getElementById("objx2").value,
      ],
      world: "MAIN",
    });
  });
  document.getElementById("objx").style.display = "block";
  document.getElementById("objxpos").style.display = "none";
  setTimeout(function () {
    document.getElementById("objx").style.display = "none";
    document.getElementById("objxpos").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function objypos() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: objy,
      args: [
        document.getElementById("objy1").value,
        document.getElementById("objy2").value,
      ],
      world: "MAIN",
    });
  });
  document.getElementById("objy").style.display = "block";
  document.getElementById("objypos").style.display = "none";
  setTimeout(function () {
    document.getElementById("objy").style.display = "none";
    document.getElementById("objypos").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function objmousepos() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: objm,
      args: [
        document.getElementById("objm1").value,
        document.getElementById("objm2").value * 10,
      ],
      world: "MAIN",
    });
  });
  document.getElementById("objm").style.display = "block";
  document.getElementById("objmousepos").style.display = "none";
  setTimeout(function () {
    document.getElementById("objm").style.display = "none";
    document.getElementById("objmousepos").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function senceinf() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: senc,
      world: "MAIN",
    });
  });
  document.getElementById("senc").style.display = "block";
  document.getElementById("senceinf").style.display = "none";
  setTimeout(function () {
    document.getElementById("senc").style.display = "none";
    document.getElementById("senceinf").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function listRLdnrl() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: list,
      args: [
        document.getElementById("list1").value,
        document.getElementById("list2").value,
        document.getElementById("list3").value,
      ],
      world: "MAIN",
    });
  });
  document.getElementById("list").style.display = "block";
  document.getElementById("listRLdnrl").style.display = "none";
  setTimeout(function () {
    document.getElementById("list").style.display = "none";
    document.getElementById("listRLdnrl").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function fltmxmqusrud() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fltm,
      args: [
        document.getElementById("fltm1").value,
        document.getElementById("fltm2").value,
        document.getElementById("fltm3").value,
      ],
      world: "MAIN",
    });
  });
  document;
  document.getElementById("fltm").style.display = "block";
  document.getElementById("fltmxmqusrud").style.display = "none";
  setTimeout(function () {
    document.getElementById("fltm").style.display = "none";
    document.getElementById("fltmxmqusrud").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function varqusrud() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: varq,
      args: [
        document.getElementById("varq1").value,
        document.getElementById("varq2").value,
      ],
      world: "MAIN",
    });
  });
  document.getElementById("varq").style.display = "block";
  document.getElementById("varqusrud").style.display = "none";
  setTimeout(function () {
    document.getElementById("varq").style.display = "none";
    document.getElementById("varqusrud").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function gifimage() {
  const fileInput = document.getElementById("gifi1");
  console.log(document.getElementById("file-input"));
  const encodeButton = document.getElementById("encode-button");
  const encodedText = document.getElementById("encoded-text");
  const file = fileInput.files[0];
  const reader = new FileReader();
  let base64data = "";
  reader.onload = () => {
    base64data = reader.result.substr(22);
    gifimage2();
  }; // 구글 바드가 짜준 코드, 비효율적이면 풀리퀘 하셈
  reader.readAsDataURL(file);
  function gifimage2() {
    chrome.tabs.query(
      { active: true, lastFocusedWindow: true },
      function (tabs) {
        var tab = tabs[0];
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: gifi,
          args: [
            base64data,
            document.getElementById("gifi2").value, // 대충 보이는게 짜르는 용도고 실제론 다른 데이터 들어가는 듯, 알아서 수정ㄱㄱ
          ],
          world: "MAIN",
        });
      }
    );
  }
  document.getElementById("gifi").style.display = "block";
  document.getElementById("gifimage").style.display = "none";
  setTimeout(function () {
    document.getElementById("gifi").style.display = "none";
    document.getElementById("gifimage").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function urlmom() {
  if (
    document
      .getElementById("urlm1")
      .value.match("https?://playentry.org/uploads/.{2}/.{2}/.*..*") != null
  ) {
    document.getElementById("urlm1").value = document
      .getElementById("urlm1")
      .value.replaceAll("http://", "")
      .replaceAll("https://", "")
      .replaceAll(".org/", ".org//");
  } else {
    document.getElementById("urlm1").value = document
      .getElementById("urlm1")
      .value.replaceAll("e", "𝖾")
      .replaceAll("t", "𝗍")
      .replaceAll("s", "𝗌")
      .replaceAll("r", "𝗋")
      .replaceAll("i", "𝗂")
      .replaceAll(".𝗂o", ".io")
      .replaceAll(".ne𝗍", ".net")
      .replaceAll(".o𝗋g", ".org")
      .replaceAll(".m𝖾", ".me")
      .replaceAll("h𝗍𝗍p", "http");
  }
  document.getElementById("urlm").style.display = "block";
  document.getElementById("urlmom").style.display = "none";
  document.getElementById("urlm1").style.color = "lime";
  setTimeout(function () {
    document.getElementById("urlm").style.display = "none";
    document.getElementById("urlmom").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function looplimit() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: loop,
      world: "MAIN",
    });
  });
  document.getElementById("loop").style.display = "block";
  document.getElementById("looplimit").style.display = "none";
  setTimeout(function () {
    document.getElementById("loop").style.display = "none";
    document.getElementById("looplimit").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function qksqhranslimit() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: qksq,
      world: "MAIN",
    });
  });
  document.getElementById("qksq").style.display = "block";
  document.getElementById("qksqhranslimit").style.display = "none";
  setTimeout(function () {
    document.getElementById("qksq").style.display = "none";
    document.getElementById("qksqhranslimit").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function wprjfltmxm() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: wprj,
      args: [
        document.getElementById("wprj1").value,
        document.getElementById("wprj2").value,
      ],
      world: "MAIN",
    });
  });
  document.getElementById("wprj").style.display = "block";
  document.getElementById("wprjfltmxm").style.display = "none";
  (results) => alert(JSON.stringify(results));
  setTimeout(function () {
    document.getElementById("wprj").style.display = "none";
    document.getElementById("wprjfltmxm").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function boostmode() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: boos,
      world: "MAIN",
    });
  });
  document.getElementById("boos").style.display = "block";
  document.getElementById("boostmode").style.display = "none";
  setTimeout(function () {
    document.getElementById("boos").style.display = "none";
    document.getElementById("boostmode").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function timerreset() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: time,
      world: "MAIN",
    });
  });
  document.getElementById("time").style.display = "block";
  document.getElementById("timerreset").style.display = "none";
  setTimeout(function () {
    document.getElementById("time").style.display = "none";
    document.getElementById("timerreset").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function selectscene() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: sele,
      world: "MAIN",
      args: [document.getElementById("sele1").value],
    });
  });
  document.getElementById("sele").style.display = "block";
  document.getElementById("selectscene").style.display = "none";
  setTimeout(function () {
    document.getElementById("sele").style.display = "none";
    document.getElementById("selectscene").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function getscene() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: gets,
      world: "MAIN",
    });
  });
  document.getElementById("gets").style.display = "block";
  document.getElementById("getscene").style.display = "none";
  setTimeout(function () {
    document.getElementById("gets").style.display = "none";
    document.getElementById("getscene").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function whenscene() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: when,
      world: "MAIN",
    });
  });
  document.getElementById("when").style.display = "block";
  document.getElementById("whenscene").style.display = "none";
  setTimeout(function () {
    document.getElementById("when").style.display = "none";
    document.getElementById("whenscene").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function clonelimit() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: clon,
      world: "MAIN",
    });
  });
  document.getElementById("clon").style.display = "block";
  document.getElementById("clonelimit").style.display = "none";
  setTimeout(function () {
    document.getElementById("clon").style.display = "none";
    document.getElementById("clonelimit").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function fpsunlock() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fpsu,
      world: "MAIN",
    });
  });
  document.getElementById("fpsu").style.display = "block";
  document.getElementById("fpsunlock").style.display = "none";
  setTimeout(function () {
    document.getElementById("fpsu").style.display = "none";
    document.getElementById("fpsunlock").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function message() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: mess,
      world: "MAIN",
      args: [document.getElementById("mess1").value],
    });
  });
  document.getElementById("mess").style.display = "block";
  document.getElementById("message").style.display = "none";
  setTimeout(function () {
    document.getElementById("mess").style.display = "none";
    document.getElementById("message").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function getmessage() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
    var tab = tabs[0];
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: getm,
      world: "MAIN",
    });
  });
  document.getElementById("getm").style.display = "block";
  document.getElementById("getmessage").style.display = "none";
  setTimeout(function () {
    document.getElementById("getm").style.display = "none";
    document.getElementById("getmessage").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
function clkorean() {
  document.getElementById("clko1").value = document
    .getElementById("clko1")
    .value.split("")
    .join("\u200B");
  document.getElementById("clko").style.display = "block";
  document.getElementById("clkorean").style.display = "none";
  document.getElementById("clko1").style.color = "lime";
  setTimeout(function () {
    document.getElementById("clko").style.display = "none";
    document.getElementById("clkorean").style.display = "block";
  }, 1000);
}
////////////////////////////////////////////////////////
document.getElementById("nickname").addEventListener("click", nickname);
document.getElementById("username").addEventListener("click", username);
document.getElementById("korean").addEventListener("click", korean);
document.getElementById("objlist").addEventListener("click", objlist);
document.getElementById("objxpos").addEventListener("click", objxpos);
document.getElementById("objypos").addEventListener("click", objypos);
document.getElementById("senceinf").addEventListener("click", senceinf);
document.getElementById("listRLdnrl").addEventListener("click", listRLdnrl);
document.getElementById("fltmxmqusrud").addEventListener("click", fltmxmqusrud);
document.getElementById("varqusrud").addEventListener("click", varqusrud);
document.getElementById("whenscene").addEventListener("click", whenscene);
document.getElementById("getmessage").addEventListener("click", getmessage);
document.getElementById("message").addEventListener("click", message);
document.getElementById("clkorean").addEventListener("click", clkorean);
document
  .getElementById("qksqhranslimit")
  .addEventListener("click", qksqhranslimit);
document.getElementById("looplimit").addEventListener("click", looplimit);
document.getElementById("objmousepos").addEventListener("click", objmousepos);
document.getElementById("wprjfltmxm").addEventListener("click", wprjfltmxm);
document.getElementById("boostmode").addEventListener("click", boostmode);
document.getElementById("urlmom").addEventListener("click", urlmom);
document.getElementById("timerreset").addEventListener("click", timerreset);
document.getElementById("getscene").addEventListener("click", getscene);
document.getElementById("selectscene").addEventListener("click", selectscene);
document.getElementById("fpsunlock").addEventListener("click", fpsunlock);
document.getElementById("clonelimit").addEventListener("click", clonelimit);
document.getElementById("gifimage").addEventListener("click", gifimage);
document.getElementById("gifi3").addEventListener("click", function () {
  document.getElementById("gifi1").click();
});
document.getElementById("gifi1").addEventListener("change", function () {
  if (document.getElementById("gifi1").value.length > 33) {
    document.getElementById("gifi3").value = `파일 선택 (${document
      .getElementById("gifi1")
      .value.substr(12, 21)}...)`;
  } else {
    document.getElementById("gifi3").value = `파일 선택 (${document
      .getElementById("gifi1")
      .value.substr(12, 21)})`;
  }
  if (document.getElementById("gifi1").value.length == 0) {
    document.getElementById("gifi3").value = `파일 선택`;
  }
});
document.getElementById("nick1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    nickname();
  }
});
document.getElementById("user1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    username();
  }
});
document.getElementById("kore1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    korean();
  }
});
document.getElementById("objx1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    objxpos();
  }
});
document.getElementById("objx2").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    objxpos();
  }
});
document.getElementById("objy1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    objypos();
  }
});
document.getElementById("objy2").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    objypos();
  }
});
document.getElementById("list1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    listRLdnrl();
  }
});
document.getElementById("list2").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    listRLdnrl();
  }
});
document.getElementById("list3").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    listRLdnrl();
  }
});
document.getElementById("fltm1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    fltmxmqusrud();
  }
});
document.getElementById("fltm2").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    fltmxmqusrud();
  }
});
document.getElementById("fltm3").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    fltmxmqusrud();
  }
});
document.getElementById("varq1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    varqusrud();
  }
});
document.getElementById("varq2").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    varqusrud();
  }
});
document.getElementById("wprj1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    wprjfltmxm();
  }
});
document.getElementById("wprj2").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    wprjfltmxm();
  }
});
document.getElementById("urlm1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    urlmom();
  }
});
document.getElementById("objm1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    objmousepos();
  }
});
document.getElementById("objm2").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    objmousepos();
  }
});
document.getElementById("sele1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    selectscene();
  }
});
document.getElementById("gifi2").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    gifimage();
  }
});
document.getElementById("mess1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    message();
  }
});
document.getElementById("mess1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    message();
  }
});
document.getElementById("clko1").addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    clkorean();
  }
});
document
  .getElementById("kore1")
  .addEventListener(
    "keydown",
    (event) => (document.getElementById("kore1").style.color = "#fff")
  );
document
  .getElementById("kore1")
  .addEventListener(
    "keydown",
    (event) => (document.getElementById("clko1").style.color = "#fff")
  );
document
  .getElementById("urlm1")
  .addEventListener(
    "keydown",
    (event) => (document.getElementById("urlm1").style.color = "#fff")
  );
